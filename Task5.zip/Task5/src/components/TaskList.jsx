import { useState, useEffect } from 'react';
import TaskService from '../services/TaskService';
import TaskForm from './TaskForm';
import './TaskList.css';

const TaskList = () => {
  const [tasks, setTasks] = useState([]);
  const [editTask, setEditTask] = useState(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(20);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = () => {
    const fetchedTasks = TaskService.getTasks();
    setTasks(fetchedTasks);
  };

  const handleToggleStatus = async (task) => {
    try {
      await TaskService.updateTask(task.id, {
        status: task.status === 'completed' ? 'pending' : 'completed'
      });
      loadTasks();
    } catch (error) {
      alert('Failed to update task status');
    }
  };

  const handleDeleteTask = async (id) => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      try {
        await TaskService.deleteTask(id);
        loadTasks();
      } catch (error) {
        alert('Failed to delete task');
      }
    }
  };

  const filteredTasks = tasks.filter(task =>
    task.assignedTo?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    task.status?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    task.comments?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const indexOfLastTask = currentPage * itemsPerPage;
  const indexOfFirstTask = indexOfLastTask - itemsPerPage;
  const currentTasks = filteredTasks.slice(indexOfFirstTask, indexOfLastTask);
  const totalPages = Math.ceil(filteredTasks.length / itemsPerPage);

  return (
    <div className="task-manager">
      <div className="header-section">
        <div className="title-section">
          <div className="menu-icon">☰</div>
          <h1>Tasks</h1>
          <div className="subtitle">All Tasks</div>
          <div className="record-count">{filteredTasks.length} records</div>
        </div>
        <div className="action-section">
          <button className="btn btn-new" onClick={() => setIsFormOpen(true)}>
            New Task
          </button>
          <button className="btn btn-refresh" onClick={loadTasks}>
            Refresh
          </button>
          <div className="search-section">
            <input
              type="text"
              placeholder="Search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <button className="search-button">🔍</button>
          </div>
        </div>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th><input type="checkbox" /></th>
              <th>Assigned To</th>
              <th>Status</th>
              <th>Due Date</th>
              <th>Priority</th>
              <th>Comments</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {currentTasks.map(task => (
              <tr key={task.id}>
                <td><input type="checkbox" /></td>
                <td className="user-cell">{task.assignedTo}</td>
                <td>{task.status}</td>
                <td>{new Date(task.dueDate).toLocaleDateString()}</td>
                <td>{task.priority}</td>
                <td>{task.comments}</td>
                <td>
                  <div className="action-buttons">
                    <button 
                      className="btn btn-edit"
                      onClick={() => setEditTask(task)}
                    >
                      Edit
                    </button>
                    <button 
                      className="btn btn-delete"
                      onClick={() => handleDeleteTask(task.id)}
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="pagination">
        <div className="items-per-page">
          <select 
            value={itemsPerPage}
            onChange={(e) => setItemsPerPage(Number(e.target.value))}
          >
            <option value={20}>20</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
        </div>
        <div className="pagination-controls">
          <button 
            onClick={() => setCurrentPage(1)} 
            disabled={currentPage === 1}
          >
            First
          </button>
          <button 
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
          >
            Prev
          </button>
          <span className="page-number">{currentPage}</span>
          <button 
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
          >
            Next
          </button>
          <button 
            onClick={() => setCurrentPage(totalPages)}
            disabled={currentPage === totalPages}
          >
            Last
          </button>
        </div>
      </div>

      {(isFormOpen || editTask) && (
        <TaskForm
          task={editTask}
          onSubmit={async (taskData) => {
            try {
              if (editTask) {
                await TaskService.updateTask(editTask.id, taskData);
              } else {
                await TaskService.addTask(taskData);
              }
              loadTasks();
              setIsFormOpen(false);
              setEditTask(null);
            } catch (error) {
              alert(editTask ? 'Failed to update task' : 'Failed to add task');
            }
          }}
          onClose={() => {
            setIsFormOpen(false);
            setEditTask(null);
          }}
        />
      )}
    </div>
  );
};

export default TaskList;
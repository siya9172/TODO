class TaskService {
    static getTasks() {
      try {
        const tasks = localStorage.getItem('tasks');
        return tasks ? JSON.parse(tasks) : [];
      } catch (error) {
        console.error('Error getting tasks:', error);
        return [];
      }
    }
  
    static addTask(taskData) {
      try {
        const tasks = this.getTasks();
        const newTask = {
          ...taskData,
          id: Date.now(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          status: 'pending',
          priority: taskData.priority || 'medium'
        };
        tasks.push(newTask);
        localStorage.setItem('tasks', JSON.stringify(tasks));
        return newTask;
      } catch (error) {
        console.error('Error adding task:', error);
        throw new Error('Failed to add task');
      }
    }
  
    static updateTask(id, updates) {
      try {
        const tasks = this.getTasks();
        const updatedTasks = tasks.map(task => 
          task.id === id 
            ? { ...task, ...updates, updatedAt: new Date().toISOString() }
            : task
        );
        localStorage.setItem('tasks', JSON.stringify(updatedTasks));
        return updatedTasks.find(task => task.id === id);
      } catch (error) {
        console.error('Error updating task:', error);
        throw new Error('Failed to update task');
      }
    }
  
    static deleteTask(id) {
      try {
        const tasks = this.getTasks();
        const filteredTasks = tasks.filter(task => task.id !== id);
        localStorage.setItem('tasks', JSON.stringify(filteredTasks));
        return true;
      } catch (error) {
        console.error('Error deleting task:', error);
        throw new Error('Failed to delete task');
      }
    }
  
    static getTaskById(id) {
      try {
        const tasks = this.getTasks();
        return tasks.find(task => task.id === id);
      } catch (error) {
        console.error('Error getting task:', error);
        return null;
      }
    }
  }
  
  export default TaskService;
  